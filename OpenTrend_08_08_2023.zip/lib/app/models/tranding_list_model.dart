class Tranding {
  String image, title, views, userimage, username, followers;
  Tranding({
    required this.image,
    required this.title,
    required this.views,
    required this.userimage,
    required this.username,
    required this.followers,
  });
}
