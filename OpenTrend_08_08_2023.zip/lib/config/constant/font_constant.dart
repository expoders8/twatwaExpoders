const kFuturaPTBold = "FuturaPTBold";
const kFuturaPTBook = "FuturaPTBook";
const kFuturaPTDemi = "FuturaPTDemi";
const kFuturaPTMedium = "FuturaPTMedium";
const kFuturalRifiRagular = "FuturalRifiRagular";
const kFuturalRifiBold = "FuturalRifiBold";
const kFuturalRifiSoftBoldItali = "FuturalRifiSoftBoldItali";
const kFuturalRiftSoftBold = "FuturalRiftSoftBold";
